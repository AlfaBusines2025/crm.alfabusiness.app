@extends('errors::minimal')

@section('title', __tr('Not Found'))
@section('code', '404')
@section('message', __tr('The page you are requesting does not exists.'))
