
    <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
        'label' => null,
        'helpText' => null,
        'prepend' => null,
        'append' => null,
        'appendText' => null,
        'prependText' => null,
    ]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
        'label' => null,
        'helpText' => null,
        'prepend' => null,
        'append' => null,
        'appendText' => null,
        'prependText' => null,
    ]); ?>
<?php foreach (array_filter(([
        'label' => null,
        'helpText' => null,
        'prepend' => null,
        'append' => null,
        'appendText' => null,
        'prependText' => null,
    ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
    <?php
    $id = $attributes->get('id');
    $dataType = $attributes->get('type');
    $formGroupClass = $attributes->get('data-form-group-class') ?? '';
    $inputGroupClass = $attributes->get('data-input-group-class') ?? '';
    if (!$id) {
        $id = sha1(json_encode($attributes->getAttributes()));
    }
    ?>
    <div class="form-group mb-1 <?php echo e($formGroupClass); ?>">
        <label for="<?php echo e($id); ?>"><?= $label ?></label>
        <?php if($append or $appendText or $prepend or $prependText): ?>
            <div class="input-group <?php echo e($inputGroupClass); ?>">
                <?php if($prepend): ?>
                    <div class="input-group-prepend">
                        <?php echo $prepend; ?>

                    </div>
                <?php endif; ?>
                <?php if($prependText): ?>
                <div class="input-group-prepend">
                    <span class="input-group-text"><?php echo $prependText; ?></span>
                </div>
            <?php endif; ?>
                <input <?php echo $attributes->merge(['class' => 'lw-form-field form-control', 'type' => 'text', 'id' => $id]); ?> />
                <?php if($append): ?>
                    <div class="input-group-append">
                        <?php echo $append; ?>

                    </div>
                <?php endif; ?>
                <?php if($appendText): ?>
                    <div class="input-group-append">
                        <span class="input-group-text"><?php echo $appendText; ?></span>
                    </div>
                <?php endif; ?>
            </div>
        <?php elseif(($dataType === 'selectize') or ($dataType === 'select')): ?>
            <?php if($dataType === 'select'): ?>
                <select <?php echo e($dataType); ?> <?php echo $attributes->merge(['class' => 'lw-form-field form-control', 'id' => $id]); ?>>
                    <?php echo $selectOptions; ?>

                </select>
            <?php elseif($dataType === 'selectize'): ?>
                <select data-lw-plugin="lwSelectize" <?php echo $attributes->merge(['class' => 'lw-form-field form-control', 'id' => $id]); ?>>
                    <?php echo $selectOptions; ?>

                </select>
            <?php endif; ?>
        <?php else: ?>
            <input <?php echo $attributes->merge(['class' => 'lw-form-field form-control', 'type' => 'text', 'id' => $id]); ?> />
        <?php endif; ?>
        <?php if($helpText): ?>
            <span class="form-text text-muted mt-3 text-sm"><?php echo e($helpText); ?></span>
        <?php endif; ?>
    </div><?php /**PATH /var/www/vhosts/estudioxy.com/marketing.estudioxy.com/resources/views/components/lw/input-field.blade.php ENDPATH**/ ?>