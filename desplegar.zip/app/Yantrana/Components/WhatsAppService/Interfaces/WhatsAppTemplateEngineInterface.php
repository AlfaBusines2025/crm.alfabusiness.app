<?php
/**
* WhatsAppTemplateEngineInterface.php - Interface file
*
* This file is part of the WhatsAppTemplate component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\WhatsAppService\Interfaces;

interface WhatsAppTemplateEngineInterface
{
}