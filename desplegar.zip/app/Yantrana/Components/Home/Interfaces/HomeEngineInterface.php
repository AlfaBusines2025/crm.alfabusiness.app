<?php
/**
* HomeEngineInterface.php - Interface file
*
* This file is part of the Home component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Home\Interfaces;

interface HomeEngineInterface
{
}
