<?php
/**
* ContactGroupRepositoryInterface.php - Interface file
*
* This file is part of the Contact component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Contact\Interfaces;

interface ContactGroupRepositoryInterface
{
}
